#javac -classpath "./lib/jade.jar" ./src/codigo/*.java

javac -classpath "./lib/jade.jar:./src/"  ./src/ontologia/**/*.java

javac -classpath "./lib/jade.jar:./src/" ./src/codigo/*.java 

 java -cp ./lib/jade.jar:./src jade.Boot -gui
