package ontologia;



/**
* Protege name: InformarFinal
* @author OntologyBeanGenerator v4.1
* @version 2024/12/10, 19:57:14
*/
public interface InformarFinal extends jade.content.AgentAction {

   /**
   * Protege name: numeroRonda
   */
   public void setNumeroRonda(int value);
   public int getNumeroRonda();

   /**
   * Protege name: ganador
   */
   public void setGanador(String value);
   public String getGanador();

   /**
   * Protege name: libro
   */
   public void setLibro(Libro value);
   public Libro getLibro();

}
