package ontologia;


import jade.util.leap.*;

/**
* Protege name: RondaSubasta
* @author OntologyBeanGenerator v4.1
* @version 2024/12/10, 19:57:14
*/
public interface RondaSubasta extends jade.content.Concept {

   /**
   * Protege name: numeroPujas
   */
   public void setNumeroPujas(int value);
   public int getNumeroPujas();

   /**
   * Protege name: numeroRonda
   */
   public void setNumeroRonda(int value);
   public int getNumeroRonda();

   /**
   * Protege name: incremento
   */
   public void setIncremento(float value);
   public float getIncremento();

   /**
   * Protege name: libro
   */
   public void setLibro(Libro value);
   public Libro getLibro();

   /**
   * Protege name: pujadores
   */
   public void addPujadores(String elem);
   public boolean removePujadores(String elem);
   public void clearAllPujadores();
   public Iterator getAllPujadores();
   public List getPujadores();
   public void setPujadores(List l);

}
