package ontologia;



/**
* Protege name: InformarCompra
* @author OntologyBeanGenerator v4.1
* @version 2024/12/10, 19:57:14
*/
public interface InformarCompra extends jade.content.AgentAction {

   /**
   * Protege name: libro
   */
   public void setLibro(Libro value);
   public Libro getLibro();

}
