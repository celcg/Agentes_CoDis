package ontologia;



/**
* Protege name: MandarDatosCompra
* @author OntologyBeanGenerator v4.1
* @version 2024/12/10, 19:57:14
*/
public interface MandarDatosCompra extends jade.content.AgentAction {

   /**
   * Protege name: telefono
   */
   public void setTelefono(int value);
   public int getTelefono();

   /**
   * Protege name: libro
   */
   public void setLibro(Libro value);
   public Libro getLibro();

}
