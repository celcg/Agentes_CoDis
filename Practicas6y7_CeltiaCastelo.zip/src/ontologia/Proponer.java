package ontologia;



/**
* Protege name: Proponer
* @author OntologyBeanGenerator v4.1
* @version 2024/12/10, 19:57:14
*/
public interface Proponer extends jade.content.AgentAction {

   /**
   * Protege name: respuesta
   */
   public void setRespuesta(boolean value);
   public boolean getRespuesta();

   /**
   * Protege name: libro
   */
   public void setLibro(Libro value);
   public Libro getLibro();

}
