package ontologia;



/**
* Protege name: Ofertar
* @author OntologyBeanGenerator v4.1
* @version 2024/12/10, 19:57:14
*/
public interface Ofertar extends jade.content.AgentAction {

   /**
   * Protege name: oferta
   */
   public void setOferta(Oferta value);
   public Oferta getOferta();

}
