package ontologia;



/**
* Protege name: InformarRonda
* @author OntologyBeanGenerator v4.1
* @version 2024/12/10, 19:57:14
*/
public interface InformarRonda extends jade.content.AgentAction {

   /**
   * Protege name: rondaSubasta
   */
   public void setRondaSubasta(RondaSubasta value);
   public RondaSubasta getRondaSubasta();

}
