package ontologia;



/**
* Protege name: Oferta
* @author OntologyBeanGenerator v4.1
* @version 2024/12/10, 19:57:14
*/
public interface Oferta extends jade.content.Concept {

   /**
   * Protege name: producto
   */
   public void setProducto(Libro value);
   public Libro getProducto();

}
