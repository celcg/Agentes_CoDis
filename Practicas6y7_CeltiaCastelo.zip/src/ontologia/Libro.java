package ontologia;



/**
* Protege name: Libro
* @author OntologyBeanGenerator v4.1
* @version 2024/12/10, 19:57:14
*/
public interface Libro extends jade.content.Concept {

   /**
   * Protege name: precio
   */
   public void setPrecio(float value);
   public float getPrecio();

   /**
   * Protege name: titulo
   */
   public void setTitulo(String value);
   public String getTitulo();

}
