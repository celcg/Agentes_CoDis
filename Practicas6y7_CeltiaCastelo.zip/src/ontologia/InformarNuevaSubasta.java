package ontologia;



/**
* Protege name: InformarNuevaSubasta
* @author OntologyBeanGenerator v4.1
* @version 2024/12/10, 19:57:14
*/
public interface InformarNuevaSubasta extends jade.content.AgentAction {

   /**
   * Protege name: incremento
   */
   public void setIncremento(float value);
   public float getIncremento();

   /**
   * Protege name: libro
   */
   public void setLibro(Libro value);
   public Libro getLibro();

}
