package ontologia.impl;


import ontologia.*;

/**
* Protege name: Oferta
* @author OntologyBeanGenerator v4.1
* @version 2024/12/10, 19:57:14
*/
public class DefaultOferta implements Oferta {

  private static final long serialVersionUID = 4848337764182558186L;

  private String _internalInstanceName = null;

  public DefaultOferta() {
    this._internalInstanceName = "";
  }

  public DefaultOferta(String instance_name) {
    this._internalInstanceName = instance_name;
  }

  public String toString() {
    return _internalInstanceName;
  }

   /**
   * Protege name: producto
   */
   private Libro producto;
   public void setProducto(Libro value) { 
    this.producto=value;
   }
   public Libro getProducto() {
     return this.producto;
   }

}
