package ontologia.impl;


import ontologia.*;

/**
* Protege name: InformarFinal
* @author OntologyBeanGenerator v4.1
* @version 2024/12/10, 19:57:14
*/
public class DefaultInformarFinal implements InformarFinal {

  private static final long serialVersionUID = 4848337764182558186L;

  private String _internalInstanceName = null;

  public DefaultInformarFinal() {
    this._internalInstanceName = "";
  }

  public DefaultInformarFinal(String instance_name) {
    this._internalInstanceName = instance_name;
  }

  public String toString() {
    return _internalInstanceName;
  }

   /**
   * Protege name: numeroRonda
   */
   private int numeroRonda;
   public void setNumeroRonda(int value) { 
    this.numeroRonda=value;
   }
   public int getNumeroRonda() {
     return this.numeroRonda;
   }

   /**
   * Protege name: ganador
   */
   private String ganador;
   public void setGanador(String value) { 
    this.ganador=value;
   }
   public String getGanador() {
     return this.ganador;
   }

   /**
   * Protege name: libro
   */
   private Libro libro;
   public void setLibro(Libro value) { 
    this.libro=value;
   }
   public Libro getLibro() {
     return this.libro;
   }

}
