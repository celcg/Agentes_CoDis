package ontologia.impl;


import ontologia.*;

/**
* Protege name: ResponderPropuesta
* @author OntologyBeanGenerator v4.1
* @version 2024/12/10, 19:57:14
*/
public class DefaultResponderPropuesta implements ResponderPropuesta {

  private static final long serialVersionUID = 4848337764182558186L;

  private String _internalInstanceName = null;

  public DefaultResponderPropuesta() {
    this._internalInstanceName = "";
  }

  public DefaultResponderPropuesta(String instance_name) {
    this._internalInstanceName = instance_name;
  }

  public String toString() {
    return _internalInstanceName;
  }

   /**
   * Protege name: libro
   */
   private Libro libro;
   public void setLibro(Libro value) { 
    this.libro=value;
   }
   public Libro getLibro() {
     return this.libro;
   }

}
