package ontologia.impl;


import ontologia.*;

/**
* Protege name: InformarNuevaSubasta
* @author OntologyBeanGenerator v4.1
* @version 2024/12/10, 19:57:14
*/
public class DefaultInformarNuevaSubasta implements InformarNuevaSubasta {

  private static final long serialVersionUID = 4848337764182558186L;

  private String _internalInstanceName = null;

  public DefaultInformarNuevaSubasta() {
    this._internalInstanceName = "";
  }

  public DefaultInformarNuevaSubasta(String instance_name) {
    this._internalInstanceName = instance_name;
  }

  public String toString() {
    return _internalInstanceName;
  }

   /**
   * Protege name: incremento
   */
   private float incremento;
   public void setIncremento(float value) { 
    this.incremento=value;
   }
   public float getIncremento() {
     return this.incremento;
   }

   /**
   * Protege name: libro
   */
   private Libro libro;
   public void setLibro(Libro value) { 
    this.libro=value;
   }
   public Libro getLibro() {
     return this.libro;
   }

}
