package ontologia.impl;


import ontologia.*;

/**
* Protege name: MandarDatosCompra
* @author OntologyBeanGenerator v4.1
* @version 2024/12/10, 19:57:14
*/
public class DefaultMandarDatosCompra implements MandarDatosCompra {

  private static final long serialVersionUID = 4848337764182558186L;

  private String _internalInstanceName = null;

  public DefaultMandarDatosCompra() {
    this._internalInstanceName = "";
  }

  public DefaultMandarDatosCompra(String instance_name) {
    this._internalInstanceName = instance_name;
  }

  public String toString() {
    return _internalInstanceName;
  }

   /**
   * Protege name: telefono
   */
   private int telefono;
   public void setTelefono(int value) { 
    this.telefono=value;
   }
   public int getTelefono() {
     return this.telefono;
   }

   /**
   * Protege name: libro
   */
   private Libro libro;
   public void setLibro(Libro value) { 
    this.libro=value;
   }
   public Libro getLibro() {
     return this.libro;
   }

}
