package ontologia.impl;


import ontologia.*;

/**
* Protege name: Proponer
* @author OntologyBeanGenerator v4.1
* @version 2024/12/10, 19:57:14
*/
public class DefaultProponer implements Proponer {

  private static final long serialVersionUID = 4848337764182558186L;

  private String _internalInstanceName = null;

  public DefaultProponer() {
    this._internalInstanceName = "";
  }

  public DefaultProponer(String instance_name) {
    this._internalInstanceName = instance_name;
  }

  public String toString() {
    return _internalInstanceName;
  }

   /**
   * Protege name: respuesta
   */
   private boolean respuesta;
   public void setRespuesta(boolean value) { 
    this.respuesta=value;
   }
   public boolean getRespuesta() {
     return this.respuesta;
   }

   /**
   * Protege name: libro
   */
   private Libro libro;
   public void setLibro(Libro value) { 
    this.libro=value;
   }
   public Libro getLibro() {
     return this.libro;
   }

}
