package ontologia.impl;


import jade.util.leap.*;
import ontologia.*;

/**
* Protege name: RondaSubasta
* @author OntologyBeanGenerator v4.1
* @version 2024/12/10, 19:57:14
*/
public class DefaultRondaSubasta implements RondaSubasta {

  private static final long serialVersionUID = 4848337764182558186L;

  private String _internalInstanceName = null;

  public DefaultRondaSubasta() {
    this._internalInstanceName = "";
  }

  public DefaultRondaSubasta(String instance_name) {
    this._internalInstanceName = instance_name;
  }

  public String toString() {
    return _internalInstanceName;
  }

   /**
   * Protege name: numeroPujas
   */
   private int numeroPujas;
   public void setNumeroPujas(int value) { 
    this.numeroPujas=value;
   }
   public int getNumeroPujas() {
     return this.numeroPujas;
   }

   /**
   * Protege name: numeroRonda
   */
   private int numeroRonda;
   public void setNumeroRonda(int value) { 
    this.numeroRonda=value;
   }
   public int getNumeroRonda() {
     return this.numeroRonda;
   }

   /**
   * Protege name: incremento
   */
   private float incremento;
   public void setIncremento(float value) { 
    this.incremento=value;
   }
   public float getIncremento() {
     return this.incremento;
   }

   /**
   * Protege name: libro
   */
   private Libro libro;
   public void setLibro(Libro value) { 
    this.libro=value;
   }
   public Libro getLibro() {
     return this.libro;
   }

   /**
   * Protege name: pujadores
   */
   private List pujadores = new ArrayList();
   public void addPujadores(String elem) { 
     pujadores.add(elem);
   }
   public boolean removePujadores(String elem) {
     boolean result = pujadores.remove(elem);
     return result;
   }
   public void clearAllPujadores() {
     pujadores.clear();
   }
   public Iterator getAllPujadores() {return pujadores.iterator(); }
   public List getPujadores() {return pujadores; }
   public void setPujadores(List l) {pujadores = l; }

}
