package ontologia.impl;


import ontologia.*;

/**
* Protege name: Ofertar
* @author OntologyBeanGenerator v4.1
* @version 2024/12/10, 19:57:14
*/
public class DefaultOfertar implements Ofertar {

  private static final long serialVersionUID = 4848337764182558186L;

  private String _internalInstanceName = null;

  public DefaultOfertar() {
    this._internalInstanceName = "";
  }

  public DefaultOfertar(String instance_name) {
    this._internalInstanceName = instance_name;
  }

  public String toString() {
    return _internalInstanceName;
  }

   /**
   * Protege name: oferta
   */
   private Oferta oferta;
   public void setOferta(Oferta value) { 
    this.oferta=value;
   }
   public Oferta getOferta() {
     return this.oferta;
   }

}
