package ontologia.impl;


import ontologia.*;

/**
* Protege name: InformarRonda
* @author OntologyBeanGenerator v4.1
* @version 2024/12/10, 19:57:14
*/
public class DefaultInformarRonda implements InformarRonda {

  private static final long serialVersionUID = 4848337764182558186L;

  private String _internalInstanceName = null;

  public DefaultInformarRonda() {
    this._internalInstanceName = "";
  }

  public DefaultInformarRonda(String instance_name) {
    this._internalInstanceName = instance_name;
  }

  public String toString() {
    return _internalInstanceName;
  }

   /**
   * Protege name: rondaSubasta
   */
   private RondaSubasta rondaSubasta;
   public void setRondaSubasta(RondaSubasta value) { 
    this.rondaSubasta=value;
   }
   public RondaSubasta getRondaSubasta() {
     return this.rondaSubasta;
   }

}
